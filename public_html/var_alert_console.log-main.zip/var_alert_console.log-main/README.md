# var_alert_console.log
Atribuição de conteúdo às variáveis e utilização do "alert" e "console.log" para exibir estes conteúdos.
